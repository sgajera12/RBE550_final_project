"""
goal_3d_cross.py

Build a 3D cross/plus structure using 16 blocks.

Structure:
  Base layer (8 blocks): 2 blocks in each cardinal direction forming a plus
  Top layer (8 blocks): Stack on top of base layer

Usage:
    python goal_3d_cross.py [gpu]
"""

import sys
import os
import numpy as np
import genesis as gs

from special_scenes_1 import create_scene_16blocks
from motion_primitives import MotionPrimitiveExecutor
from predicates import extract_predicates, print_predicates

BLOCK_SIZE = 0.04  # 4cm blocks
SAFE_HEIGHT = 0.20  # 20cm safe height for movements

# ---------------------------------------------------------------------------
# 1) Initialize Genesis
# ---------------------------------------------------------------------------
if len(sys.argv) > 1 and sys.argv[1] == "gpu":
    gs.init(backend=gs.gpu, logging_level="Warning", logger_verbose_time=False)
else:
    gs.init(backend=gs.cpu, logging_level="Warning", logger_verbose_time=False)

scene, franka, blocks_state = create_scene_16blocks()

# Strong gripper control
franka.set_dofs_kp(
    np.array([4500, 4500, 3500, 3500, 2000, 2000, 2000, 2000, 2000]),
)
franka.set_dofs_kv(
    np.array([450, 450, 350, 350, 200, 200, 200, 200, 200]),
)
franka.set_dofs_force_range(
    np.array([-87, -87, -87, -87, -12, -12, -12, -200, -200]),
    np.array([ 87,  87,  87,  87,  12,  12,  12,  200,  200]),
)

print("=" * 80)
print("GOAL: 3D CROSS STRUCTURE (16 BLOCKS)")
print("=" * 80)

# ---------------------------------------------------------------------------
# 2) Move robot to a safe home configuration
# ---------------------------------------------------------------------------
safe_home = np.array(
    [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785, 0.04, 0.04], dtype=float
)

print("\nMoving to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()

for i in range(200):
    alpha = (i + 1) / 200.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

print("At home\n")

for _ in range(50):
    franka.control_dofs_position(safe_home)
    scene.step()

# Let physics settle
for _ in range(100):
    scene.step()

# ---------------------------------------------------------------------------
# 3) BUILD THE 3D CROSS STRUCTURE
# ---------------------------------------------------------------------------

executor = MotionPrimitiveExecutor(scene, franka, blocks_state)

# Assembly area on the LEFT side (blocks are on the RIGHT)
CENTER_X = 0.40
CENTER_Y = -0.10

print("\n" + "=" * 80)
print("BUILDING 3D CROSS - BASE LAYER FIRST")
print("=" * 80)

# ============================================================================
# HELPER FUNCTION: Place second block next to first using lift-move-lower
# ============================================================================
def place_block_next_to_reference(executor, block_id, ref_block_id, direction):
    """
    Place a block next to a reference block by:
    1. Picking it up
    2. Lifting to safe height
    3. Moving horizontally to target position
    4. Lowering and placing
    
    Args:
        block_id: ID of block to place
        ref_block_id: ID of reference block
        direction: 'x+', 'x-', 'y+', or 'y-'
    """
    print(f"\n[cross] Placing {block_id} {direction} from {ref_block_id}...")
    
    # Pick up the block
    if not executor.pick_up(block_id):
        print(f"[cross] ❌ Failed to pick up {block_id}")
        return False
    
    # Get reference block actual position
    ref_pos = executor._block_center(ref_block_id)
    ref_x = float(ref_pos[0])
    ref_y = float(ref_pos[1])
    
    # Calculate target position based on direction
    if direction == 'x+':
        final_x = ref_x + BLOCK_SIZE
        final_y = ref_y
    elif direction == 'x-':
        final_x = ref_x - BLOCK_SIZE
        final_y = ref_y
    elif direction == 'y+':
        final_x = ref_x
        final_y = ref_y + BLOCK_SIZE
    elif direction == 'y-':
        final_x = ref_x
        final_y = ref_y - BLOCK_SIZE
    else:
        print(f"[cross] ❌ Invalid direction: {direction}")
        return False
    
    # STEP 1: Lift to safe height
    hand = executor.robot.get_link("hand")
    current_hand_pos = np.array(hand.get_pos())
    safe_pos = current_hand_pos.copy()
    safe_pos[2] = SAFE_HEIGHT
    
    print(f"[cross]   Lifting to safe height ({SAFE_HEIGHT}m)...")
    q_safe = executor._ik_for_pose(safe_pos, executor.grasp_quat)
    if q_safe is None:
        print(f"[cross] ❌ Failed IK for safe height")
        return False
    
    current_q = executor.robot.get_qpos()
    if hasattr(current_q, "cpu"):
        start_q = current_q.cpu().numpy().copy()
    else:
        start_q = np.array(current_q, dtype=float, copy=True)
    
    # Slow lift
    for i in range(60):
        alpha = (i + 1) / 60.0
        q = (1 - alpha) * start_q + alpha * q_safe
        q[-2:] = executor.config.gripper_closed_width
        executor.robot.control_dofs_position(q)
        executor.scene.step()
    
    # STEP 2: Move horizontally to target position
    target_safe_pos = np.array([final_x, final_y, SAFE_HEIGHT])
    
    print(f"[cross]   Moving horizontally to ({final_x:.4f}, {final_y:.4f})...")
    q_target = executor._ik_for_pose(target_safe_pos, executor.grasp_quat)
    if q_target is None:
        print(f"[cross] ❌ Failed IK for target position")
        return False
    
    current_q = executor.robot.get_qpos()
    if hasattr(current_q, "cpu"):
        start_q = current_q.cpu().numpy().copy()
    else:
        start_q = np.array(current_q, dtype=float, copy=True)
    
    # Slow horizontal movement
    for i in range(80):
        alpha = (i + 1) / 80.0
        q = (1 - alpha) * start_q + alpha * q_target
        q[-2:] = executor.config.gripper_closed_width
        executor.robot.control_dofs_position(q)
        executor.scene.step()
    
    # STEP 3: Lower down and place
    if not executor.put_down(x=final_x, y=final_y):
        print(f"[cross] ❌ Failed to place {block_id}")
        return False
    
    for _ in range(100):
        executor.scene.step()
    
    actual_pos = executor._block_center(block_id)
    print(f"[cross]   ✓ Placed at ({actual_pos[0]:.4f}, {actual_pos[1]:.4f}, {actual_pos[2]:.4f})")
    return True

# ============================================================================
# BASE LAYER: 8 blocks in plus pattern
# ============================================================================
print("\n" + "=" * 80)
print("BASE LAYER: 8 blocks in plus pattern")
print("=" * 80)
print("\nPattern (top view):")
print("      [b1][b2]")
print("      ")
print("[b7][b8]  [b3][b4]")
print("      ")
print("      [b5][b6]")

# ------------------------------------------------------------------------
# NORTH DIRECTION: Place b1 (reference), then b2 next to it
# ------------------------------------------------------------------------
print(f"\n{'='*60}")
print("NORTH: b1 (reference) + b2 (next to b1)")
print('='*60)

# Place b1 at the north position (reference block for north direction)
north_x = CENTER_X
north_y = CENTER_Y - BLOCK_SIZE  # One block north of center

print(f"\n>> Placing b1 (NORTH REFERENCE) at ({north_x:.4f}, {north_y:.4f})")
if not executor.pick_up('b1'):
    print("❌ Failed to pick up b1")
    sys.exit(1)
if not executor.put_down(x=north_x, y=north_y):
    print("❌ Failed to place b1")
    sys.exit(1)
for _ in range(100):
    scene.step()
print("✓ b1 placed")

# Place b2 to the right of b1 (x+)
if not place_block_next_to_reference(executor, 'b2', 'b1', 'x+'):
    sys.exit(1)

# Return to home
print("\n>> Returning to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()
for i in range(100):
    alpha = (i + 1) / 100.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

# ------------------------------------------------------------------------
# EAST DIRECTION: Place b3 (reference), then b4 next to it
# ------------------------------------------------------------------------
print(f"\n{'='*60}")
print("EAST: b3 (reference) + b4 (next to b3)")
print('='*60)

# Place b3 at the east position
east_x = CENTER_X + BLOCK_SIZE
east_y = CENTER_Y

print(f"\n>> Placing b3 (EAST REFERENCE) at ({east_x:.4f}, {east_y:.4f})")
if not executor.pick_up('b3'):
    print("❌ Failed to pick up b3")
    sys.exit(1)
if not executor.put_down(x=east_x, y=east_y):
    print("❌ Failed to place b3")
    sys.exit(1)
for _ in range(100):
    scene.step()
print("✓ b3 placed")

# Place b4 in front of b3 (y+)
if not place_block_next_to_reference(executor, 'b4', 'b3', 'y+'):
    sys.exit(1)

# Return to home
print("\n>> Returning to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()
for i in range(100):
    alpha = (i + 1) / 100.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

# ------------------------------------------------------------------------
# SOUTH DIRECTION: Place b5 (reference), then b6 next to it
# ------------------------------------------------------------------------
print(f"\n{'='*60}")
print("SOUTH: b5 (reference) + b6 (next to b5)")
print('='*60)

# Place b5 at the south position
south_x = CENTER_X
south_y = CENTER_Y + BLOCK_SIZE

print(f"\n>> Placing b5 (SOUTH REFERENCE) at ({south_x:.4f}, {south_y:.4f})")
if not executor.pick_up('b5'):
    print("❌ Failed to pick up b5")
    sys.exit(1)
if not executor.put_down(x=south_x, y=south_y):
    print("❌ Failed to place b5")
    sys.exit(1)
for _ in range(100):
    scene.step()
print("✓ b5 placed")

# Place b6 to the right of b5 (x+)
if not place_block_next_to_reference(executor, 'b6', 'b5', 'x+'):
    sys.exit(1)

# Return to home
print("\n>> Returning to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()
for i in range(100):
    alpha = (i + 1) / 100.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

# ------------------------------------------------------------------------
# WEST DIRECTION: Place b7 (reference), then b8 next to it
# ------------------------------------------------------------------------
print(f"\n{'='*60}")
print("WEST: b7 (reference) + b8 (next to b7)")
print('='*60)

# Place b7 at the west position
west_x = CENTER_X - BLOCK_SIZE
west_y = CENTER_Y

print(f"\n>> Placing b7 (WEST REFERENCE) at ({west_x:.4f}, {west_y:.4f})")
if not executor.pick_up('b7'):
    print("❌ Failed to pick up b7")
    sys.exit(1)
if not executor.put_down(x=west_x, y=west_y):
    print("❌ Failed to place b7")
    sys.exit(1)
for _ in range(100):
    scene.step()
print("✓ b7 placed")

# Place b8 in front of b7 (y+)
if not place_block_next_to_reference(executor, 'b8', 'b7', 'y+'):
    sys.exit(1)

# Return to home
print("\n>> Returning to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()
for i in range(100):
    alpha = (i + 1) / 100.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

print("\n" + "="*80)
print("✓ BASE LAYER COMPLETE (8 blocks in tight plus formation)")
print("="*80)

# Let physics settle
for _ in range(150):
    scene.step()

# ============================================================================
# TOP LAYER: Stack 8 blocks on top of base
# ============================================================================
print("\n" + "=" * 80)
print("TOP LAYER: Stack 8 blocks on base (b9-b16)")
print("=" * 80)

stacking_pairs = [
    ('b9', 'b1', 'north-left'),
    ('b10', 'b2', 'north-right'),
    ('b11', 'b3', 'east-back'),
    ('b12', 'b4', 'east-front'),
    ('b13', 'b5', 'south-left'),
    ('b14', 'b6', 'south-right'),
    ('b15', 'b7', 'west-back'),
    ('b16', 'b8', 'west-front'),
]

for block_id, target_id, position in stacking_pairs:
    print(f"\n>> Stacking {block_id} on {target_id} ({position})")
    
    if not executor.pick_up(block_id):
        print(f"  ❌ Failed to pick up {block_id}")
        sys.exit(1)
    
    current_predicates = extract_predicates(scene, franka, blocks_state)
    
    if not executor.stack_on(target_id, current_predicates):
        print(f"  ❌ Failed to stack {block_id} on {target_id}")
        sys.exit(1)
    
    for _ in range(100):
        scene.step()
    print(f"  ✓ {block_id} stacked on {target_id}")

# Return to home
print("\n>> Returning to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()
for i in range(100):
    alpha = (i + 1) / 100.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

print("\n✓ TOP LAYER COMPLETE")

# ---------------------------------------------------------------------------
# 4) FINAL VERIFICATION
# ---------------------------------------------------------------------------

print("\n" + "=" * 80)
print("FINAL STRUCTURE")
print("=" * 80)

for _ in range(100):
    scene.step()

final_predicates = extract_predicates(scene, franka, blocks_state)
print_predicates(final_predicates)

print("\n" + "=" * 80)
print("🎉 SUCCESS! 3D CROSS STRUCTURE COMPLETE!")
print("=" * 80)
print("\nFinal configuration:")
print("  - Base layer: 8 blocks (2 in each cardinal direction, touching)")
print("  - Top layer: 8 blocks (stacked directly on base)")
print("  - Total: 16 blocks")
print("  - Blocks are tightly packed with minimal gaps")

print("\n👀 Viewing final result. Press Ctrl+C to exit...")
try:
    while True:
        scene.step()
except KeyboardInterrupt:
    print("\nExiting...")