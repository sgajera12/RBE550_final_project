"""
goal_3d_cross_tamp.py

Build a 3D cross/plus structure using PROPER TAMP pipeline.

Structure:
  Base layer (8 blocks): 2 blocks in each cardinal direction forming a plus
  Top layer (8 blocks): Stack on top of base layer

Uses TAMP: Task Planning (Pyperplan) → Motion Primitives → Re-grounding loop

Usage:
    python goal_3d_cross_tamp.py [gpu]
"""

import sys
import os
import numpy as np
import genesis as gs

from special_scenes_1 import create_scene_16blocks
from motion_primitives import MotionPrimitiveExecutor
from predicates import extract_predicates, print_predicates
from task_planner import generate_pddl_problem, call_pyperplan, plan_to_string

BLOCK_SIZE = 0.04  # 4cm blocks

# ---------------------------------------------------------------------------
# 1) Initialize Genesis
# ---------------------------------------------------------------------------
if len(sys.argv) > 1 and sys.argv[1] == "gpu":
    gs.init(backend=gs.gpu, logging_level="Warning", logger_verbose_time=False)
else:
    gs.init(backend=gs.cpu, logging_level="Warning", logger_verbose_time=False)

scene, franka, blocks_state = create_scene_16blocks()

# Strong gripper control
franka.set_dofs_kp(
    np.array([4500, 4500, 3500, 3500, 2000, 2000, 2000, 2000, 2000]),
)
franka.set_dofs_kv(
    np.array([450, 450, 350, 350, 200, 200, 200, 200, 200]),
)
franka.set_dofs_force_range(
    np.array([-87, -87, -87, -87, -12, -12, -12, -200, -200]),
    np.array([ 87,  87,  87,  87,  12,  12,  12,  200,  200]),
)

print("=" * 80)
print("GOAL: 3D CROSS STRUCTURE (16 BLOCKS) - TAMP PIPELINE")
print("=" * 80)

# ---------------------------------------------------------------------------
# 2) Move robot to a safe home configuration
# ---------------------------------------------------------------------------
safe_home = np.array(
    [0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785, 0.04, 0.04], dtype=float
)

print("\nMoving to home...")
current = franka.get_qpos()
if hasattr(current, "cpu"):
    current = current.cpu().numpy()

for i in range(200):
    alpha = (i + 1) / 200.0
    q = (1.0 - alpha) * current + alpha * safe_home
    franka.control_dofs_position(q)
    scene.step()

print("At home\n")

for _ in range(50):
    franka.control_dofs_position(safe_home)
    scene.step()

# Let physics settle
for _ in range(100):
    scene.step()

# ---------------------------------------------------------------------------
# 3) Define GOAL predicates for 3D cross structure
# ---------------------------------------------------------------------------

# IMPORTANT: The goal is purely symbolic - PDDL will figure out how to achieve it
# We specify WHAT we want, not HOW to build it

# Base layer configuration (8 blocks on table):
#       [b1][b2]      NORTH
# [b7][b8]  [b3][b4]  WEST-EAST
#       [b5][b6]      SOUTH

# Top layer (8 blocks stacked):
# b9→b1, b10→b2, b11→b3, b12→b4, b13→b5, b14→b6, b15→b7, b16→b8

goal_predicates = {
    # ===== BASE LAYER (8 blocks on table) =====
    "ONTABLE(b1)",
    "ONTABLE(b2)",
    "ONTABLE(b3)",
    "ONTABLE(b4)",
    "ONTABLE(b5)",
    "ONTABLE(b6)",
    "ONTABLE(b7)",
    "ONTABLE(b8)",
    
    # ===== TOP LAYER (8 blocks stacked on base) =====
    "ON(b9,b1)",   # North-left
    "ON(b10,b2)",  # North-right
    "ON(b11,b3)",  # East-back
    "ON(b12,b4)",  # East-front
    "ON(b13,b5)",  # South-left
    "ON(b14,b6)",  # South-right
    "ON(b15,b7)",  # West-back
    "ON(b16,b8)",  # West-front
    
    # ===== CLEAR blocks (all top layer blocks must be clear) =====
    "CLEAR(b9)",
    "CLEAR(b10)",
    "CLEAR(b11)",
    "CLEAR(b12)",
    "CLEAR(b13)",
    "CLEAR(b14)",
    "CLEAR(b15)",
    "CLEAR(b16)",
    
    # Gripper empty at the end
    "HANDEMPTY()",
}

blocks = ["b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", 
          "b9", "b10", "b11", "b12", "b13", "b14", "b15", "b16"]

print("\n" + "=" * 80)
print("GOAL STATE (3D CROSS):")
print("=" * 80)
print("\nBase layer (on table): b1-b8")
print("Top layer: b9-b16 stacked on base")
print("\nPattern (top view):")
print("      [b9] [b10]       (on b1, b2)")
print("      ")
print("[b15][b16]  [b11][b12] (on b7, b8, b3, b4)")
print("      ")
print("     [b13][b14]        (on b5, b6)")
print("\nGoal predicates:")
for p in sorted(goal_predicates):
    print(f"  {p}")

# ---------------------------------------------------------------------------
# 4) INCREMENTAL TAMP - Plan for small groups of blocks at a time
# ---------------------------------------------------------------------------

executor = MotionPrimitiveExecutor(scene, franka, blocks_state)

domain_file = os.path.join(os.path.dirname(__file__), "blocksworld.pddl")

# Assembly center for placing blocks
CENTER_X = 0.45
CENTER_Y = 0.0

# Define WHERE each block should be placed when put-down is called
BLOCK_PLACEMENT_POSITIONS = {
    # NORTH arm
    'b1': (CENTER_X, CENTER_Y - BLOCK_SIZE),
    'b2': (CENTER_X + BLOCK_SIZE-0.002, CENTER_Y - BLOCK_SIZE),
    
    # EAST arm
    'b3': (CENTER_X + 2*BLOCK_SIZE, CENTER_Y),
    'b4': (CENTER_X + 2*BLOCK_SIZE, CENTER_Y + BLOCK_SIZE),
    
    # SOUTH arm
    'b5': (CENTER_X, CENTER_Y + 2*BLOCK_SIZE),
    'b6': (CENTER_X + BLOCK_SIZE-0.002, CENTER_Y + 2*BLOCK_SIZE),
    
    # WEST arm
    'b7': (CENTER_X - BLOCK_SIZE - 0.02, CENTER_Y),
    'b8': (CENTER_X - BLOCK_SIZE-0.02, CENTER_Y + BLOCK_SIZE),
}

print("\n" + "=" * 80)
print("INCREMENTAL TAMP - Planning for blocks in small batches")
print("=" * 80)

# ============================================================================
# PHASE 1: Place base layer blocks using TAMP
# ============================================================================

print("\n" + "=" * 80)
print("PHASE 1: Place base layer (b1-b8) using TAMP")
print("=" * 80)

# For each base block, use TAMP to plan placing it on the table
# The key: We'll use put-down with designated positions

base_blocks_to_place = [
    ('b1', 'NORTH-left'),
    ('b2', 'NORTH-right'),
    ('b3', 'EAST-back'),
    ('b4', 'EAST-front'),
    ('b5', 'SOUTH-left'),
    ('b6', 'SOUTH-right'),
    ('b7', 'WEST-back'),
    ('b8', 'WEST-front'),
]

for block_id, location in base_blocks_to_place:
    print(f"\n{'='*60}")
    print(f"Placing {block_id} at {location} using TAMP")
    print(f"{'='*60}")
    
    # Get target position
    if block_id not in BLOCK_PLACEMENT_POSITIONS:
        print(f"❌ No position defined for {block_id}")
        sys.exit(1)
    
    target_x, target_y = BLOCK_PLACEMENT_POSITIONS[block_id]
    print(f"  Target position: ({target_x:.4f}, {target_y:.4f})")
    
    # TAMP loop for this single block
    iteration = 0
    max_iterations = 10
    
    # Goal: This block should be ONTABLE
    block_goal = {
        f"ONTABLE({block_id})",
        f"CLEAR({block_id})",
        "HANDEMPTY()",
    }
    
    # Check if already at goal
    current_predicates = extract_predicates(scene, franka, blocks_state)
    if block_goal.issubset(current_predicates):
        print(f"  {block_id} already ONTABLE - just checking position...")
        
        # Even if ONTABLE, we need to move it to the right position
        # Pick it up and place at designated spot
        if not executor.pick_up(block_id):
            print(f"  ❌ Failed to pick up {block_id}")
            sys.exit(1)
        
        if not executor.put_down(x=target_x, y=target_y):
            print(f"  ❌ Failed to place {block_id}")
            sys.exit(1)
        
        print(f"  ✓ {block_id} repositioned to designated location")
        
        # Settle and return home
        for _ in range(80):
            scene.step()
        
        current = franka.get_qpos()
        if hasattr(current, "cpu"):
            current = current.cpu().numpy()
        for i in range(60):
            alpha = (i + 1) / 60.0
            q = (1.0 - alpha) * current + alpha * safe_home
            franka.control_dofs_position(q)
            scene.step()
        
        continue  # Move to next block
    
    # Use TAMP to plan getting this block ONTABLE
    while iteration < max_iterations:
        iteration += 1
        print(f"\n  [TAMP Iteration {iteration}]")
        
        # Extract predicates
        current_predicates = extract_predicates(scene, franka, blocks_state)
        
        # Filter to this block only
        filtered_predicates = set()
        for pred in current_predicates:
            if "HANDEMPTY()" in pred or "HOLDING(" in pred:
                if "HOLDING(" in pred and block_id in pred:
                    filtered_predicates.add(pred)
                elif "HANDEMPTY()" in pred:
                    filtered_predicates.add(pred)
            elif block_id in pred:
                # Only include predicates about this block
                other_blocks = [f"b{i}" for i in range(1, 17) if f"b{i}" != block_id]
                has_other = any(other in pred for other in other_blocks)
                if not has_other:
                    filtered_predicates.add(pred)
        
        print(f"    Predicates: {sorted(filtered_predicates)}")
        
        # Check goal
        if block_goal.issubset(filtered_predicates):
            print(f"    ✓ {block_id} is ONTABLE")
            break
        
        # Plan
        print(f"    Planning for {block_id}...")
        problem_string = generate_pddl_problem(
            filtered_predicates,
            block_goal,
            [block_id],
            f"place_{block_id}_iter{iteration}",
        )
        
        plan = call_pyperplan(domain_file, problem_string)
        
        if not plan:
            print(f"    ❌ No plan found")
            sys.exit(1)
        
        # Execute first action
        action_name, args = plan[0]
        print(f"    Executing: {action_name.upper()}({', '.join(args)})")
        
        success = False
        if action_name == "pick-up":
            success = executor.pick_up(args[0])
        elif action_name == "put-down":
            # Place at designated position!
            success = executor.put_down(x=target_x, y=target_y)
        elif action_name == "unstack":
            success = executor.pick_up(args[0])
        
        if not success:
            print(f"    ⚠️  Action failed, re-planning...")
        else:
            print(f"    ✓ Action completed")
        
        # Settle
        for _ in range(80):
            scene.step()
        
        # Return home if gripper empty
        current_preds = extract_predicates(scene, franka, blocks_state)
        if "HANDEMPTY()" in current_preds:
            current = franka.get_qpos()
            if hasattr(current, "cpu"):
                current = current.cpu().numpy()
            for i in range(60):
                alpha = (i + 1) / 60.0
                q = (1.0 - alpha) * current + alpha * safe_home
                franka.control_dofs_position(q)
                scene.step()
    
    print(f"  ✓ {block_id} placed at {location}")

print("\n✓ PHASE 1 COMPLETE - Base layer arranged using TAMP!")

# Let physics settle
for _ in range(150):
    scene.step()

# ============================================================================
# PHASE 2: Stack top layer blocks using TAMP
# ============================================================================

print("\n" + "=" * 80)
print("PHASE 2: Stack top layer (b9-b16) using TAMP")
print("=" * 80)

stacking_plan = [
    ('b9', 'b1', 'North-left'),
    ('b10', 'b2', 'North-right'),
    ('b11', 'b3', 'East-back'),
    ('b12', 'b4', 'East-front'),
    ('b13', 'b5', 'South-left'),
    ('b14', 'b6', 'South-right'),
    ('b15', 'b7', 'West-back'),
    ('b16', 'b8', 'West-front'),
]

for top_block, base_block, position in stacking_plan:
    print(f"\n{'='*60}")
    print(f"Stacking {top_block} on {base_block} ({position})")
    print(f"{'='*60}")
    
    iteration = 0
    max_iterations = 15  # Increased for potential re-planning
    
    # Goal: Stack this one block
    single_goal = {
        f"ON({top_block},{base_block})",
        f"CLEAR({top_block})",
        "HANDEMPTY()",
    }
    
    # Blocks involved: the top block and base block
    involved_blocks = [top_block, base_block]
    
    while iteration < max_iterations:
        iteration += 1
        print(f"\n[Iteration {iteration}]")
        
        # Extract ALL predicates
        all_predicates = extract_predicates(scene, franka, blocks_state)
        
        # Create a clean set of predicates for planning
        # Include: HANDEMPTY/HOLDING, and anything about our 2 blocks ONLY
        # IMPORTANT: We need CLEAR status of BOTH blocks
        filtered_predicates = set()
        
        for pred in all_predicates:
            # Always include gripper state
            if "HANDEMPTY()" in pred or "HOLDING(" in pred:
                # Check if HOLDING mentions one of our blocks
                if "HOLDING(" in pred:
                    if top_block in pred or base_block in pred:
                        filtered_predicates.add(pred)
                    # If holding some other block, skip it
                else:
                    filtered_predicates.add(pred)
                continue
            
            # For other predicates, check if they're about our blocks
            # Extract block IDs from the predicate
            pred_blocks = []
            for block_id in ["b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8",
                           "b9", "b10", "b11", "b12", "b13", "b14", "b15", "b16"]:
                if block_id in pred:
                    pred_blocks.append(block_id)
            
            # Include predicate if it ONLY mentions our involved blocks
            # This includes ONTABLE(b10), ONTABLE(b2), CLEAR(b10), CLEAR(b2)
            if len(pred_blocks) > 0:
                if all(block in involved_blocks for block in pred_blocks):
                    filtered_predicates.add(pred)
        
        # CRITICAL FIX: Also check for ON predicates involving the base block
        # If something is ON(x, base_block), we need to know base_block is NOT clear
        for pred in all_predicates:
            # Check for ON(something, base_block)
            if "ON(" in pred and base_block in pred:
                # This tells us base_block is not clear
                # Remove CLEAR(base_block) if it exists
                clear_pred = f"CLEAR({base_block})"
                if clear_pred in filtered_predicates:
                    filtered_predicates.remove(clear_pred)
                    print(f"    Note: {base_block} is not clear (something is on it)")
        
        print(f"Filtered predicates for {involved_blocks}:")
        for p in sorted(filtered_predicates):
            print(f"  {p}")
        
        # Check if goal already reached
        if single_goal.issubset(filtered_predicates):
            print(f"✓ {top_block} already stacked on {base_block}!")
            break
        
        # Ensure both blocks exist in the filtered predicates
        # At minimum we need to know their state
        has_top_block_state = any(top_block in pred for pred in filtered_predicates)
        has_base_block_state = any(base_block in pred for pred in filtered_predicates)
        
        if not has_top_block_state:
            print(f"⚠️ WARNING: {top_block} state not found in predicates!")
            print(f"   All predicates: {all_predicates}")
            print(f"   This block might not be tracked properly.")
            # Try to add it manually
            filtered_predicates.add(f"ONTABLE({top_block})")
            filtered_predicates.add(f"CLEAR({top_block})")
            print(f"   Added default state for {top_block}")
        
        if not has_base_block_state:
            print(f"⚠️ WARNING: {base_block} state not found in predicates!")
            # This shouldn't happen for base blocks, but add it anyway
            filtered_predicates.add(f"ONTABLE({base_block})")
            filtered_predicates.add(f"CLEAR({base_block})")
        
        # Generate PDDL problem
        print(f"Planning to stack {top_block} on {base_block}...")
        problem_string = generate_pddl_problem(
            filtered_predicates,
            single_goal,
            involved_blocks,
            f"stack_{top_block}",
        )
        
        # DEBUG: Save the problem file
        debug_file = f"/tmp/debug_stack_{top_block}_iter{iteration}.pddl"
        with open(debug_file, "w") as f:
            f.write(problem_string)
        print(f"  Debug: Problem saved to {debug_file}")
        
        plan = call_pyperplan(domain_file, problem_string)
        
        if not plan:
            print(f"❌ No plan found for stacking {top_block} on {base_block}")
            print(f"   Check problem file at {debug_file}")
            print(f"   Current predicates: {filtered_predicates}")
            print(f"   Goal: {single_goal}")
            
            # Try to diagnose the issue
            if f"ONTABLE({top_block})" not in filtered_predicates and f"HOLDING({top_block})" not in filtered_predicates:
                print(f"   Issue: {top_block} is not ONTABLE or HOLDING - cannot pick up!")
            if "HANDEMPTY()" not in filtered_predicates:
                print(f"   Issue: Gripper is not empty - cannot pick up!")
            
            sys.exit(1)
        
        print(f"  Plan: {len(plan)} actions")
        for i, (action, args) in enumerate(plan, 1):
            print(f"    {i}. {action.upper()}({', '.join(args)})")
        
        # Execute first action
        action_name, args = plan[0]
        print(f"\nExecuting: {action_name.upper()}({', '.join(args)})")
        
        success = False
        if action_name == "pick-up":
            success = executor.pick_up(args[0])
        elif action_name == "put-down":
            success = executor.put_down()
        elif action_name == "stack":
            # Need full predicates for stack_on
            full_predicates = extract_predicates(scene, franka, blocks_state)
            success = executor.stack_on(args[1], full_predicates)
        elif action_name == "unstack":
            success = executor.pick_up(args[0])
        else:
            print(f"❌ Unknown action: {action_name}")
            sys.exit(1)
        
        if not success:
            print("⚠️  Action failed! Will re-plan in next iteration...")
            # Don't exit - let it re-plan
        else:
            print("✓ Action completed")
        
        # Settle
        for _ in range(80):
            scene.step()
        
        # Return home ONLY if gripper is empty
        current_preds = extract_predicates(scene, franka, blocks_state)
        if "HANDEMPTY()" in current_preds:
            print("  Returning to home (gripper empty)...")
            current = franka.get_qpos()
            if hasattr(current, "cpu"):
                current = current.cpu().numpy()
            for i in range(60):
                alpha = (i + 1) / 60.0
                q = (1.0 - alpha) * current + alpha * safe_home
                franka.control_dofs_position(q)
                scene.step()
        else:
            print("  Holding block - staying in place for next action...")
    
    if iteration >= max_iterations:
        print(f"❌ Failed to stack {top_block} on {base_block} after {max_iterations} iterations")
        sys.exit(1)

print("\n✓ PHASE 2 COMPLETE - All top blocks stacked!")

# ---------------------------------------------------------------------------
# 5) FINAL VERIFICATION
# ---------------------------------------------------------------------------

print("\n" + "=" * 80)
print("FINAL VERIFICATION")
print("=" * 80)

for _ in range(100):
    scene.step()

final_predicates = extract_predicates(scene, franka, blocks_state)
print_predicates(final_predicates)

if goal_predicates.issubset(final_predicates):
    print("=" * 80)
    print("🎉 SUCCESS! 3D CROSS STRUCTURE COMPLETE!")
    print("=" * 80)
    print("\nFinal configuration:")
    print("  - Base layer: b1-b8 on table (plus formation)")
    print("  - Top layer: b9-b16 stacked on base")
    print("  - Total: 16 blocks forming 3D cross")
else:
    print("❌ Goal not fully achieved")
    missing = goal_predicates - final_predicates
    print(f"\nMissing predicates: {missing}")

print(f"\nTotal iterations: {iteration}")
print("\n👀 Viewing final result. Press Ctrl+C to exit...")
try:
    while True:
        scene.step()
except KeyboardInterrupt:
    print("\nExiting...")